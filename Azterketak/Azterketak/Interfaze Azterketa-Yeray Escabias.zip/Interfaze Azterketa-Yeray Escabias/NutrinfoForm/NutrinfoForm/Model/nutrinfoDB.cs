﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NutrinfoForm
{
    public class nutrinfoDB : DbContext
    {
        public nutrinfoDB() : base(nameOrConnectionString: "nutrinfoDB")
        { }
        public DbSet<elikagaia> elikagaia { get; set; }
        public DbSet<informazioa> informazioa { get; set; }
        public DbSet<osagaia> osagaia { get; set; }
       
        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("public");
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
