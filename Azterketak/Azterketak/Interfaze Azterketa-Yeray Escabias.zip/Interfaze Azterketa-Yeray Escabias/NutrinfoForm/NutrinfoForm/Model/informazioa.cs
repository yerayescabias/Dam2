﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NutrinfoForm
{
    public partial class informazioa
    {
        [Key]
        public int Id { get; set; }
        public int OsagaiaId { get; set; }
        public int Urtea { get; set; }
        public int Kantitatea { get; set; }
        public int ElikagaiaId { get; set; }

        [ForeignKey("ElikagaiaId")]
        public virtual elikagaia elikagaia { get; set; }

        [ForeignKey("OsagaiaId")]
        public virtual osagaia osagaia { get; set; }
    }
}
