﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;


namespace NutrinfoForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (var db = new nutrinfoDB())
            {

                var data = db.elikagaia.ToList();

                if (data != null)
                {
                    if (data.Count > 0)
                    {
                        List<elikagaia>elikagaialista = data.ToList();
                        dataGridView1.DataSource = elikagaialista;    

                        
                 
                    }
                }
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0 || dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show("Mesedez,elikagai bat aukeratu behar duzu, eta ez gehiago");
            }
            else
            {
                elikagaia elikagaia = dataGridView1.SelectedRows[0].DataBoundItem as elikagaia;
                using (var db = new nutrinfoDB())
                {
                    var ElikagaiData = db.informazioa.Include("osagaia")
                        .Where(i => i.ElikagaiaId == elikagaia.Id).GroupBy(b => b.osagaia.Izena).ToDictionary(g => g.Key, g => g.Sum(b => b.Kantitatea));

                    if (ElikagaiData != null)
                    {
                        if (ElikagaiData.Count > 0)
                        {
                            var kontrol = grafikoa1.Controls.OfType<System.Windows.Forms.DataVisualization.Charting.Chart>();
                            foreach (var item in kontrol)
                            {
                                item.DataSource = ElikagaiData;
                                item.Series[0].YValueMembers = "Value";
                                item.Series[0].XValueMember = "Key";
                                item.DataBind();

                            }
                        }
                    }

                }
            }
        }


    }
}
