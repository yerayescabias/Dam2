package paagbi.pojoak;

import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Nota")
public class Notak {

    List<Nota> notak;
    @XmlElement(name="Notak")
    public List<Nota> getNotak() {
        return notak;
    }

    public void setNotak(List<Nota> notak) {
        this.notak = notak;
    }

    public void add(Nota nota) {
        if (this.notak == null) {
            this.notak = new ArrayList<Nota>();
        }
        this.notak.add(nota);

    }

    /**
     * Metodo honek noten zerrenda errebisatu eta ikasleen batezbestekoa kalkulatzen du.
     * @return Ikasleak objektu bat
     * 
     */
    
    public Ikasleak getIkasleenBB() {
        Ikasleak ikasleak = new Ikasleak();
        double ikasgaia=0;
        double guztira =0;
        for (Nota n : getNotak()) {
            for(Nota a : getNotak()){
                guztira +=a.getNota();
                ikasgaia++;
            }
            Ikaslea ikasle = new Ikaslea();
            ikasle.setIkaslea(n.getIkaslea());
            ikasle.setBatezbestekoa(guztira/ikasgaia);
            ikasleak.add(ikasle);    
        }
        return ikasleak;
    }

    /**
     * Ikasle baten nota guztien batezbestekoa kalkulatzen du.
     * 
     * @param ikaslea Adibidez, madariaga.idoia
     * @return Ikaslea motako objektu bat, atributo bezala batezbestekoa kalkulatuta
     *         daukana.
     */
    public Ikaslea getIkaslearenBB(String strIkaslea) {
        int guztira = 0;// ikasleari dagozkion noten batura joango gara gehitzen hemen
        int notaKopurua = 0;// ikasle honi dagozkion nota kopurua joango gara kontatzen hemen
        for (Nota n : notak) {
            if (n.getIkaslea().equals(strIkaslea)) {
                guztira += n.getNota();
                notaKopurua++;
            }
        }
        return new Ikaslea(strIkaslea, guztira / notaKopurua);
    }

    @Override
    public String toString() {
        StringBuffer str = new StringBuffer();
        for (Nota n : this.notak) {
            str.append(n.toString());
            str.append("\n");
        }
        return str.toString();
    }

}
