package paagbi.atzipenekoak;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;

import paagbi.pojoak.Ikaslea;
import paagbi.pojoak.Ikasleak;
import paagbi.pojoak.Nota;
import paagbi.pojoak.Notak;


public class JsonIkasleak {

    public String strFileIn;
    public String strFileOut;

    /**
     * Konstruktoreak parametro bakarra jasotzen badu,
     * sarrera fitxategiaren izena jaso dugula suposatuko dugu.
     */
    public JsonIkasleak(String strFile) {
        strFileIn = strFile;
    }

    /**
     * Konstruktoreak parametro bi jasotzen baditu,
     * lehengoa, sarrera fitxategiaren izena dela eta bigarrena irteerakoarena
     * direla suposatuko dugu.
     * Sarrera fitxategirik erabiliko ez badugu, kate hutsa erabiliko dugu lehen
     * parametro moduan.
     */
    public JsonIkasleak(String strFileIn, String strFileOut) {
        this.strFileIn = strFileIn;
        this.strFileOut = strFileOut;
    }


    /**
     * Jasotako datuak strFileOut fitxategiak idatziko ditu json formatuan
     * 
     * @param ikasleak Ikasleak klaseko objektu bat
     * @return Idatzitako ikasle kopurua
     */
    public int idatzi(Ikasleak ikasleak) {
        int lineak =0;
         try (OutputStream fos = new FileOutputStream(strFileOut);
            JsonWriter writer = Json.createWriter(fos)) {
            JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
            for(Ikaslea ikasle : ikasleak.getIkasleak()){
                JsonObjectBuilder objectBuilder = Json.createObjectBuilder().
                add("ikaslea",ikasle.getIkaslea()).
                add("batazbestekoa", ikasle.getBatezbestekoa());
                arrayBuilder.add(objectBuilder.build());
                lineak++;
            }
            JsonObject jsonObject = Json.createObjectBuilder().add("info",arrayBuilder.build()).build();
            writer.writeObject(jsonObject);
            }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return lineak;
    }

    /**
     * Notak objetu bat jaso
     * @param notak
     * @return Idatzitako ikasle kopurua
     */
    public int idatzi(Notak notak) {
        int lineak =0;
        try (OutputStream fos = new FileOutputStream(strFileOut);
        JsonWriter writer = Json.createWriter(fos)) {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        Ikasleak ikasleak = new Ikasleak();
        ikasleak = notak.getIkasleenBB();
        for(Ikaslea ikaslea : ikasleak.getIkasleak()){
            JsonObjectBuilder objectBuilder = Json.createObjectBuilder().
            add("ikaslea",ikaslea.getIkaslea()).
            add("batazbestekoa",ikaslea.getBatezbestekoa());
            arrayBuilder.add(objectBuilder.build());
            lineak++;
        }
        JsonObject jsonObject = Json.createObjectBuilder().add("Info", arrayBuilder.build()).build();
        writer.writeObject(jsonObject);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return lineak;

    }
}
