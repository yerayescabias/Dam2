package paagbi.mainklaseak;

import paagbi.atzipenekoak.JsonNotak;
import paagbi.pojoak.Notak;

/**
 * Programa hau ez aldatu!!!
 * Exekutatzerakoan zera inprimatu behar du kontsolatik:
 * Nota[1, alvarez.josu, 2024-02-28, program, 10.0]
 * Nota[2, arizmendiarrieta.maider, 2024-02-28, program, 9.5]
 * Nota[3, arrizabalaga.ignacio, 2024-02-28, program, 9.0]
 * ...
 * 
 * Hori gertatzeko JsonNotak klaseko irakurri metodoa aldatu behar duzu.
 */
public class JsonaKontsolanInprimatu {
    public static void main(String[] args) {
        JsonNotak jsona= new JsonNotak("datuak/Notak.json");
        Notak notak = jsona.irakurri();
        System.out.println(notak);
    }
}
