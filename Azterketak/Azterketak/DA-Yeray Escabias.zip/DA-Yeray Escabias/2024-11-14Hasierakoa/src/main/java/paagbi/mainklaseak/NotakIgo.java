package paagbi.mainklaseak;

import paagbi.atzipenekoak.Csva;
import paagbi.atzipenekoak.JsonNotak;
import paagbi.atzipenekoak.Xmla;
import paagbi.pojoak.Nota;
import paagbi.pojoak.Notak;

/**
 * Datu-iturria: Notak.csv
 * Sortutako fitxategia: NotaHobetuak.xml
 * Programa honek nota guztiak puntu bat igoko ditu,
 * kontutan izanik notarik altuena 10 dela.
 * 'atzipenekoak' paketeko klaseak erabiliz egin, noski.
 */
public class NotakIgo {
  public static void main(String[] args) {
      Csva csva = new Csva("datuak/Notak.csv");
      Xmla xmla = new Xmla(null,"datuak/NotaHobetuak.xml");
      Notak notak = new Notak();
      Notak notaBerriak = new Notak();


      notak =csva.irakurri();
      try {
        for (Nota nota : notak.getNotak()) {
          if(!(nota.getNota()==10.00 || nota.getNota()==9.5)){
            nota.setNota(nota.getNota()+1.00);
            notaBerriak.add(nota);
           
          }else if(nota.getNota()==9.5){
            nota.setNota(nota.getNota()+0.50);
            notaBerriak.add(nota);
          }
        
      }
      System.out.println(xmla.idatzi(notak)+" nota idatzi dira xml fitxategian");
      } catch (NullPointerException e) {
        System.out.println("Fitxategia utzik dago");
      }

      JsonNotak jsonNotak = new JsonNotak("datuak/Notak.json");
      notak=jsonNotak.irakurri();
      
        
      
     
      


  }

}