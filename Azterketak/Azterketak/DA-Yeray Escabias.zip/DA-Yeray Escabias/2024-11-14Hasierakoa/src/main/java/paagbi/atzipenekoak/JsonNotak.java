package paagbi.atzipenekoak;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.JsonWriter;

import paagbi.pojoak.Nota;
import paagbi.pojoak.Notak;

public class JsonNotak {

    public String strFileIn;
    public String strFileOut;

    /**
     * Konstruktoreak parametro bakarra jasotzen badu,
     * sarrera fitxategiaren izena jaso dugula suposatuko dugu.
     */
    public JsonNotak(String strFile) {
        strFileIn = strFile;
    }

    /**
     * Konstruktoreak parametro bi jasotzen baditu,
     * lehengoa, sarrera fitxategiaren izena dela eta bigarrena irteerakoarena
     * direla suposatuko dugu.
     * Sarrera fitxategirik erabiliko ez badugu, kate hutsa erabiliko dugu lehen
     * parametro moduan.
     */
    public JsonNotak(String strFileIn, String strFileOut) {
        this.strFileIn = strFileIn;
        this.strFileOut = strFileOut;
    }

    /** Metodo honek metodoak notak dauzkan .json fitxategi bat irakurtzen du, 
     * strFileIn atributoak adierazitakoa,
     * eta Notak klaseko objektu bat itzuli. 
     */
    public Notak irakurri() {
        Notak notak = new Notak();
        try(InputStream inputS = new FileInputStream(new File(strFileIn))) {
            JsonReader reader = Json.createReader((inputS));
            JsonStructure structure = reader.read();
            JsonArray arraynota = structure.asJsonArray();
            
            
            for (int i = 0; i < arraynota.size(); i++) {
                
                JsonObject objectjson =arraynota.getJsonObject(i);
                Nota nota = new Nota();
                    nota.setId(objectjson.getInt("id"));
                    nota.setIkaslea(objectjson.getString("ikaslea"));
                    nota.setData(objectjson.getString("data"));
                    nota.setIkasgaia(objectjson.getString("ikasgaia"));
                    nota.setNota(objectjson.getJsonNumber("nota").doubleValue());
                    notak.add(nota);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return notak;
    }

    public int idatzi(Notak notak) {
        int notaKopurua = 0;
        JsonArray model = null;
        JsonArrayBuilder jab = Json.createArrayBuilder();
        for (Nota n : notak.getNotak()) {
            jab.add(Json.createObjectBuilder()
                    .add("id", n.getId())
                    .add("ikaslea", n.getIkaslea())
                    .add("data", n.getData())
                    .add("ikasgaia", n.getIkasgaia())
                    .add("nota",n.getNota())
                    .build());
            notaKopurua++;
        }
        model=jab.build();

        try (JsonWriter jsonWriter = Json.createWriter(new FileOutputStream(strFileOut))) {
            jsonWriter.writeArray(model);
        } catch (FileNotFoundException fnfe) {
            System.out.println("Fitxategia sortzerakoan arazoak.");
        }
        return notaKopurua;

    }
}
